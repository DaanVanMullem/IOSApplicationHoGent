//
//  Games.swift
//  FirstProjectTest2
//
//  Created by user208206 on 12/27/21.
//

import Foundation

struct Games: Codable {
    var games: [Game]
}
